from django.contrib import admin
from newsapp import models

admin.site.register(models.NewsUnit)
